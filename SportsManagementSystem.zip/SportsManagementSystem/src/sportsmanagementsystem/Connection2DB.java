
package sportsmanagementsystem;

import java.sql.*;
import javax.swing.JTable;
import net.proteanit.sql.DbUtils;

public class Connection2DB {

    public Connection newConnection(){
        
        Connection Con = null;
        Statement st;
        ResultSet rs;
        String path = "SportsDatabase.mdb";
        String url = "jdbc:ucanaccess://" + path;
        try{
            Con = DriverManager.getConnection(url);
            st =Con.createStatement();
            String sql = "SELECT * FROM Players";
            rs  = st.executeQuery(sql);
            while(rs.next()){
                String pName,pSport,pContact,pLocation;
                Integer pAge,pMatches,pWon;
                pName = rs.getString("PlayerName");
                pAge = rs.getInt("Age");
                pContact = rs.getString("Contact");
                pLocation = rs.getString("Location");
                pSport = rs.getString("Sport");
                pMatches = rs.getInt("Matches");
                pWon = rs.getInt("MatchesWon");
                
            }
        }catch(Exception e){
            System.out.print(e);
        }
        return Con;
    
    } 
   public void Show(JTable table){
       try {
           
           Connection con = newConnection();
           Statement st = con.createStatement();
           String qry = "SELECT * FROM Players";
           ResultSet rs = st.executeQuery(qry);
           table.setModel(DbUtils.resultSetToTableModel(rs));
       }catch(Exception ex){
           System.out.println("ex");
       }
       
   }
  
   
  
   }

